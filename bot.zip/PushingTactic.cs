﻿/*using Pirates;

namespace Hydra

{
    
    class PushingTactic
    {
        
        int abletopush = 0;
        
        public string Preform(Pirate pirate, TaskType Taskofpirate)
        {
            if (Taskofpirate == Task.ESCORT)
                ImEscort(pirate);
            else if (Taskofpirate == Task.BERSERKER)
                ImBerserker(pirate);
            else if (Taskofpirate == Task.MINER)
                ImMiner(pirate);
            else if (Taskofpirate == Task.DEFAULT)
                ImDefault(pirate);
            else if (Taskofpirate == Task.MOLE)
                ImMoler(pirate);
            else
                return "never happened";
        }
        
        public void ImEscort(Pirate pirate)
        {
            
        }
        
        public void ImBerserker(Pirate pirate)
        {
            
        }
        
        public void ImMiner(Pirate pirate)
        {
            
        }
        
        public void ImDefault(Pirate pirate)
        {
            
        }
        
        public void ImMoler(Pirate pirate)
        {
            
        }
    }
    
    
    
    
    
}*/